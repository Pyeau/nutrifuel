# ==========================================================
# ATHLETIC DIET RECOMMENDATION SYSTEM - MODEL TRAINING SCRIPT
# ==========================================================
# Hybrid Architecture:
# - Random Forest (Supervised Learning)
# - K-Means (Unsupervised Learning)
# - Integrated for Personalized Food Recommendations
# ==========================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import joblib
import warnings
import sys

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestClassifier
from sklearn.cluster import KMeans
from sklearn.metrics import accuracy_score, classification_report, silhouette_score

from imblearn.over_sampling import SMOTE
from imblearn.pipeline import Pipeline as ImbPipeline

# Streamlined output
warnings.filterwarnings('ignore', category=UserWarning)
sys.stdout.reconfigure(line_buffering=True)


# ==========================================================
# PART 0 — LOAD ATHLETE DATA
# ==========================================================
def load_and_explore_data(filepath):
    """Load the athlete dataset for Random Forest training"""
    try:
        df = pd.read_csv(filepath)
        print(f"✅ '{filepath}' loaded successfully.")
        print(f"Shape: {df.shape}")
        print("Columns:", df.columns.tolist())
        return df
    except FileNotFoundError:
        print(f"❌ Error: '{filepath}' not found.")
        return None


# ==========================================================
# PART 1 — RANDOM FOREST (SUPERVISED LEARNING)
# ==========================================================
def build_meal_plan_classifier(df):
    """
    Train Random Forest with SMOTE integrated to handle class imbalance.
    Predicts 'Meal_Plan' from athlete attributes.
    """
    print("\n" + "=" * 60)
    print("🏋️ TRAINING RANDOM FOREST MODEL (Supervised Learning)")
    print("=" * 60)

    target = 'Meal_Plan'
    numerical_features = [
        'Age', 'Weight (kg)', 'Height (m)', 'BMI',
        'Fat_Percentage', 'Avg_BPM', 'Resting_BPM', 'Experience_Level'
    ]
    categorical_features = ['Gender', 'Goals']
    features = numerical_features + categorical_features

    # --- Validation ---
    missing = [c for c in [target] + features if c not in df.columns]
    if missing:
        print(f"❌ Missing required columns: {missing}")
        return None

    df_clean = df.dropna(subset=[target] + features)
    if df_clean.empty:
        print("❌ No valid data for training after removing missing rows.")
        return None

    # ✅ Normalize the 'Goals' column to match Streamlit input format
    df_clean['Goals'] = df_clean['Goals'].replace({
        'Build Muscle': 'High Protein High Carb',
        'Endurance': 'High Carb',
        'HIIT': 'High Protein Low Carb',
        'Weight Loss': 'High Protein Low Carb',
        'General': 'Balanced'
    })

    X = df_clean[features]
    y = df_clean[target]

    print(f"\n📊 Dataset Summary:")
    print(f"Samples: {len(df_clean)}")
    print("Meal Plan Distribution:")
    print(y.value_counts())

    # --- Preprocessing ---
    numeric_transformer = Pipeline([
        ('imputer', SimpleImputer(strategy='median')),
        ('scaler', StandardScaler())
    ])
    categorical_transformer = Pipeline([
        ('imputer', SimpleImputer(strategy='most_frequent')),
        ('onehot', OneHotEncoder(handle_unknown='ignore'))
    ])
    preprocessor = ColumnTransformer([
        ('num', numeric_transformer, numerical_features),
        ('cat', categorical_transformer, categorical_features)
    ])

    # --- SMOTE Oversampling ---
    from imblearn.over_sampling import SMOTE
    from imblearn.pipeline import Pipeline as ImbPipeline

    smote = SMOTE(random_state=42)

    # --- Random Forest Classifier ---
    from sklearn.ensemble import RandomForestClassifier
    model = RandomForestClassifier(
        n_estimators=150,
        random_state=42,
        n_jobs=-1,
        class_weight='balanced'
    )

    # --- Full Pipeline ---
    model_pipeline = ImbPipeline(steps=[
        ('preprocessor', preprocessor),
        ('smote', smote),
        ('model', model)
    ])

    # --- Split Data ---
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import accuracy_score, classification_report

    if len(y.unique()) <= 1:
        print("❌ Not enough unique target values to train the model.")
        return None

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=42
    )

    # --- Train Model ---
    print("\n🔄 Training Random Forest model with SMOTE...")
    model_pipeline.fit(X_train, y_train)
    print("✅ Model training complete!")

    # --- Evaluate Model ---
    y_pred = model_pipeline.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    print(f"\n📈 Accuracy: {acc * 100:.2f}%")
    print("\n--- Classification Report ---")
    print(classification_report(y_test, y_pred))

    # --- Save Model ---
    import joblib
    joblib.dump(model_pipeline, 'meal_plan_model.joblib')
    print("\n💾 Model saved as 'meal_plan_model.joblib'")

    return model_pipeline


# ==========================================================
# PART 2 — K-MEANS CLUSTERING (UNSUPERVISED LEARNING)
# ==========================================================
def map_cluster_to_meal_plan(food_df, n_clusters):
    """
    Dynamically map K-Means clusters to model-driven meal plan names
    using similarity between cluster nutrition patterns and Random Forest target distributions.
    """

    print("\n🧠 Dynamically mapping clusters to functional meal plan roles...")

    cluster_stats = (
        food_df.groupby('Food_Cluster')[['Proteins', 'Carbs', 'Fats', 'Calories']]
        .mean()
        .reset_index()
    )

    # Compute relative nutrient proportions (so scale doesn’t dominate)
    totals = cluster_stats[['Proteins', 'Carbs', 'Fats']].sum(axis=1)
    cluster_stats['p_ratio'] = cluster_stats['Proteins'] / totals
    cluster_stats['c_ratio'] = cluster_stats['Carbs'] / totals
    cluster_stats['f_ratio'] = cluster_stats['Fats'] / totals

    # --- Define the target profiles (your intent) ---
    # No hardcoding of labels; instead, pattern matching by macro balance
    ideal_profiles = {
        "High Protein Low Carb":      {"p": 0.5,  "c": 0.2,  "f": 0.3, "goal": "Build Muscle"},
        "High Carb":                  {"p": 0.2,  "c": 0.6,  "f": 0.2, "goal": "Endurance"},
        "High Protein High Carb High Fat": {"p": 0.35, "c": 0.35, "f": 0.3, "goal": "HIIT"},
        "Balanced":                   {"p": 0.25, "c": 0.45, "f": 0.25, "goal": "Other"},
    }

    # --- Compute cosine similarity between each cluster and each ideal profile ---
    def cosine_sim(a, b):
        return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-8)

    mapping = {}
    for i, row in cluster_stats.iterrows():
        cluster_vec = np.array([row['p_ratio'], row['c_ratio'], row['f_ratio']])
        best_label, best_score = None, -1

        for label, prof in ideal_profiles.items():
            profile_vec = np.array([prof['p'], prof['c'], prof['f']])
            sim = cosine_sim(cluster_vec, profile_vec)
            if sim > best_score:
                best_score = sim
                best_label = label

        mapping[row['Food_Cluster']] = best_label

    print("\n📊 Cluster → Predicted Category Mapping:")
    for cid, label in mapping.items():
        sim_row = cluster_stats.loc[cluster_stats['Food_Cluster'] == cid].iloc[0]
        print(
            f"  Cluster {cid}: {label}  "
            f"(P={sim_row['p_ratio']:.2f}, C={sim_row['c_ratio']:.2f}, F={sim_row['f_ratio']:.2f})"
        )

    # --- Add goal alignment (your desired semantic meaning) ---
    goal_map = {v["goal"]: k for k, v in ideal_profiles.items()}
    print("\n🎯 Goal Alignment Mapping:")
    for goal, cat in goal_map.items():
        print(f"  {goal:12s} → {cat}")

    return mapping


def build_food_clusters(food_df):
    """Apply K-Means to group foods by nutritional profile, choose k via silhouette."""
    print("\n" + "=" * 60)
    print("🍽️ CLUSTERING FOODS WITH K-MEANS (improved)")
    print("=" * 60)

    features = ['Proteins', 'Carbs', 'Fats', 'Calories']
    food_df = food_df.dropna(subset=features).copy()

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(food_df[features])

    # Choose k by silhouette score (try k range 3..8)
    best_k = None
    best_score = -1.0
    scores = {}
    for k in range(3, 9):
        ktmp = KMeans(n_clusters=k, random_state=42, n_init=10)
        labels = ktmp.fit_predict(X_scaled)
        try:
            s = silhouette_score(X_scaled, labels)
        except Exception:
            s = -1
        scores[k] = s
        print(f"k={k}, silhouette={s:.4f}")
        if s > best_score:
            best_score = s
            best_k = k

    # safe fallback
    if best_k is None:
        best_k = 5

    print(f"🎯 Selected k = {best_k} (silhouette={best_score:.4f})")

    kmeans = KMeans(n_clusters=best_k, random_state=42, n_init=10)
    food_df['Food_Cluster'] = kmeans.fit_predict(X_scaled)

    sil = silhouette_score(X_scaled, food_df['Food_Cluster'])
    print(f"📊 Final silhouette score: {sil:.4f}")

    # Build mapping based on cluster stats and enforce required categories
    mapping = map_cluster_to_meal_plan(food_df, best_k)

    # Apply mapping to dataframe
    food_df['Meal_Plan'] = food_df['Food_Cluster'].map(mapping).fillna('Others')

    # Save KMeans/scaler/mapping for later use (optional)
    joblib.dump(kmeans, 'food_kmeans_model.joblib')
    joblib.dump(scaler, 'food_scaler.joblib')
    joblib.dump(mapping, 'cluster_mealplan_mapping.joblib')
    print("💾 Saved kmeans, scaler and cluster->mealplan mapping.")

    return food_df


# ==========================================================
# PART 3 — FOOD DATABASE PREPROCESSING
# ==========================================================
def load_and_process_food_database():
    """Preprocess food data and apply K-Means clustering."""
    print("\n" + "=" * 60)
    print("🥗 LOADING AND PROCESSING FOOD DATABASE")
    print("=" * 60)

    try:
        food_df = pd.read_csv('cleaned_nutrition_dataset_per100g.csv')
        print(f"✅ Loaded {len(food_df)} food items")

        # --- Standardize column names ---
        rename_cols = {
            'food': 'meal_name',
            'Carbohydrates (g per 100g)': 'Carbs',
            'carbohydrates': 'Carbs',
            'carbs': 'Carbs',
            'Protein (g per 100g)': 'Proteins',
            'protein': 'Proteins',
            'Fat (g per 100g)': 'Fats',
            'fat': 'Fats',
            'Calories (kcal per 100g)': 'Calories',
            'calories': 'Calories'
        }
        food_df = food_df.rename(columns={k: v for k, v in rename_cols.items() if k in food_df.columns})

        # --- 🧹 CLEANUP STEP 1: Remove unwanted food items ---
        if 'meal_name' in food_df.columns:
            banned_keywords = [
                "raw", "oil", "butter", "margarine", "lard", "fat",
                "shortening", "batter", "gravy", "sauce", "dressing",
                "powder", "dry", "mix", "flour", "yeast"
            ]
            pattern = '|'.join(banned_keywords)
            before = len(food_df)
            food_df = food_df[~food_df['meal_name'].str.lower().str.contains(pattern, na=False)]
            after = len(food_df)
            print(f"🧽 Removed {before - after} items containing {banned_keywords}")

        # --- 🧹 CLEANUP STEP 2: Ensure numeric nutrition values ---
        for col in ['Proteins', 'Carbs', 'Fats', 'Calories']:
            if col in food_df.columns:
                food_df[col] = pd.to_numeric(food_df[col], errors='coerce')
                food_df[col] = food_df[col].apply(lambda x: np.nan if pd.isna(x) or x < 0 else x)
                food_df[col] = food_df[col].fillna(food_df[col].mean()).round(1)

        print("\n⚙️ After cleaning:")
        print(food_df[['Proteins', 'Carbs', 'Fats', 'Calories']].describe())

        # --- Create nutritional level bins (optional for analysis) ---
        for col in ['Proteins', 'Carbs', 'Fats', 'Calories']:
            if col in food_df.columns:
                labels = ["Very Low", "Low", "Moderate", "High", "Very High"]
                try:
                    food_df[f"{col}_Level"] = pd.qcut(food_df[col], q=5, labels=labels, duplicates='drop')
                except ValueError:
                    food_df[f"{col}_Level"] = pd.cut(food_df[col], bins=5, labels=labels)

        # --- Cluster foods ---
        food_df = build_food_clusters(food_df)

        # --- Save cleaned data ---
        food_df.to_csv('improved_food_database.csv', index=False)
        print("💾 Saved as 'improved_food_database.csv'")
        print(food_df['Meal_Plan'].value_counts())

        return food_df

    except FileNotFoundError:
        print("❌ 'cleaned_nutrition_dataset_per100g.csv' not found.")
        return None



# ==========================================================
# MAIN EXECUTION
# ==========================================================
if __name__ == "__main__":
    print("=" * 60)
    print("🚀 ATHLETIC DIET RECOMMENDATION SYSTEM - TRAINING PIPELINE")
    print("=" * 60)

    # 1. Train Random Forest on athlete profiles
    df = load_and_explore_data('Final_data.csv')
    if df is not None:
        rf_model = build_meal_plan_classifier(df)
    else:
        rf_model = None
        print("⚠️ Skipped Random Forest training (no data).")

    # 2. Process food database and cluster
    food_df = load_and_process_food_database()

    print("\n" + "=" * 60)
    print("✅ TRAINING COMPLETE")
    print("=" * 60)
    if rf_model is not None:
        print("✓ Random Forest model trained and saved.")
    if food_df is not None:
        print("✓ Food database clustered and saved.")
    print("You can now run your Streamlit app 🎯")
