import streamlit as st
import pandas as pd
import joblib
import numpy as np

# --- 1. Page Configuration ---
st.set_page_config(
    page_title="Athletic Diet Recommendation System",
    layout="wide",
    initial_sidebar_state="expanded"
)

# --- 2. Custom CSS for Professional Design ---
st.markdown("""
<style>
/* Base Resets and Font */
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700&display=swap');
* {box-sizing: border-box; font-family: 'IBM Plex Sans', sans-serif;}
header, footer {visibility: hidden;}

/* Main App Background */
.stApp {
    /* Light, professional background */
    background: #ffffff;
    color: #202124; /* primary dark text */
}

/* Sidebar Styling */
[data-testid="stSidebar"] {
    background-color: #ffffff; /* match app background for a clean look */
    border-right: 1px solid rgba(60,64,67,0.08);
    padding: 1.5rem 1rem;
    box-shadow: none;
}

/* Headers */
h1 {
    color: #202124;
    font-weight: 700;
    font-size: 2.0rem !important;
    margin: 0.5rem 0 1rem 0;
    text-align: center;
    letter-spacing: -0.2px;
    line-height: 1.15;
}

h2, h3 {
h2, h3 {
    color: #202124;
    font-weight: 600;
    letter-spacing: -0.2px;
    margin: 1rem 0;
}

/* Cards */
.main-card {
.main-card {
    background: #ffffff;
    border: 1px solid rgba(60,64,67,0.08);
    border-radius: 8px;
    padding: 1.4rem;
    margin: 1rem 0;
    transition: transform 0.12s ease, box-shadow 0.12s ease;
}

.main-card:hover {
    transform: translateY(-1px);
    box-shadow: 0 6px 14px rgba(60,64,67,0.06);
}

/* Form Elements */
.stTextInput > div {
.stTextInput > div {
    background-color: #f8f9fa !important; /* very light input bg */
    border: 1px solid rgba(60,64,67,0.08) !important;
    border-radius: 6px !important;
    color: #202124 !important;
    transition: all 0.12s ease !important;
}

.stSelectbox > div, .stNumberInput > div {
.stSelectbox > div, .stNumberInput > div {
    background-color: #f8f9fa !important;
    border: 1px solid rgba(60,64,67,0.08) !important;
    border-radius: 6px !important;
    color: #202124 !important;
    transition: all 0.12s ease !important;
}

.stSelectbox > div:hover, .stNumberInput > div:hover, .stTextInput > div:hover {
.stSelectbox > div:hover, .stNumberInput > div:hover, .stTextInput > div:hover {
    border-color: rgba(66,133,244,0.22) !important; /* subtle blue accent on focus */
    box-shadow: 0 0 0 3px rgba(66,133,244,0.06) !important;
}

/* Form labels, help text and small UI text - make high contrast */
label,
.stMarkdown > label,
.stTextInput label,
.stSelectbox label,
.stNumberInput label,
.css-1okebmr, /* fallback Streamlit label class (varies by version) */
.css-1v0mbdj /* another fallback */ {
    color: #202124 !important;
    font-weight: 600 !important;
    opacity: 0.98 !important;
}

/* Input placeholder / value text should remain visible (dark on light inputs) */
.stTextInput input,
.stNumberInput input,
input[type="text"],
input[type="number"],
select {
    color: #0b0b0b !important; /* keep input values readable on light input backgrounds */
}

/* Sidebar small text and headings */
[data-testid="stSidebar"] h4,
[data-testid="stSidebar"] p,
[data-testid="stSidebar"] label,
[data-testid="stSidebar"] div {
    color: #202124 !important;
}

/* Buttons */
.stButton > button {
.stButton > button {
    width: 100%;
    height: 3rem;
    background: linear-gradient(90deg, #1a73e8, #1a73e8) !important; /* Google-like blue */
    color: #ffffff !important;
    border: none !important;
    border-radius: 6px !important;
    font-weight: 600 !important;
    letter-spacing: 0.4px;
    text-transform: uppercase;
    font-size: 0.9rem !important;
    transition: transform 0.12s ease, box-shadow 0.12s ease !important;
}

.stButton > button:hover {
    transform: translateY(-1px);
    box-shadow: 0 6px 14px rgba(26,115,232,0.18) !important;
}

/* Metrics and Info Boxes */
[data-testid="stMetricValue"] {

[data-testid="stMetricValue"] {
    color: #202124 !important;
    font-size: 1.4rem !important;
    font-weight: 700 !important;
}

/* Metric labels (the small descriptive text above/beside metric values) */
[data-testid="metric-label"],
.stMetricLabel,
[data-testid="metric-label"],
.css-1aumxhk { /* fallback generic class if present */
    color: #202124 !important;
    font-size: 0.95rem !important;
    font-weight: 600 !important;
    opacity: 0.95 !important;
    text-shadow: none !important;
}

.stAlert {
    background-color: rgba(255, 255, 255, 0.08) !important;
    color: #202124 !important;
    border: 1px solid rgba(255, 255, 255, 0.15) !important;
    border-radius: 8px !important;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05) !important;
}

/* DataFrames/Tables */
[data-testid="stDataFrame"] {
    background-color: rgba(28, 37, 65, 0.7) !important;
    border-radius: 6px !important;
    border: 1px solid rgba(201, 214, 223, 0.1) !important;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1) !important;
}

[data-testid="stDataFrame"] td, [data-testid="stDataFrame"] th {
    color: #202124 !important;
    background-color: transparent !important;
    border-color: rgba(201, 214, 223, 0.1) !important;
    font-weight: 500 !important;
}

/* Expander */
.streamlit-expanderHeader {
    background-color: rgba(25, 118, 210, 0.05) !important;
    border-radius: 8px !important;
    border: 1px solid rgba(130, 177, 255, 0.1) !important;
    color: #202124 !important;
    transition: all 0.3s ease !important;
}

.streamlit-expanderHeader:hover {
    background-color: rgba(25, 118, 210, 0.1) !important;
    border-color: rgba(130, 177, 255, 0.2) !important;
}

/* Custom Metric Cards */
.metric-card {

.metric-card {
    background: #ffffff;
    border: 1px solid rgba(60,64,67,0.08);
    border-radius: 8px;
    padding: 1rem;
    text-align: center;
}

.metric-card:hover {
    transform: translateY(-1px);
    box-shadow: 0 6px 12px rgba(60,64,67,0.06);
}

.metric-value {
    color: #202124;
    font-size: 1.4rem;
    font-weight: 700;
    margin: 0.3rem 0;
}

.metric-label {
    color: #5f6368;
    font-size: 0.9rem;
    opacity: 0.95;
}

.metric-value {
    color: #202124;
    font-size: 1.8rem;
    font-weight: 700;
    margin: 0.5rem 0;
}

.metric-label {
    color: #202124;
    font-size: 0.9rem;
    opacity: 0.8;
}

</style>
""", unsafe_allow_html=True)


# --- 3. Load Models and Data ---
@st.cache_data
def load_data():
    try:
        return pd.read_csv('improved_food_database.csv')
    except FileNotFoundError:
        st.error("❌ 'improved_food_database.csv' not found!")
        return None

@st.cache_resource
def load_model():
    try:
        return joblib.load('meal_plan_model.joblib')
    except FileNotFoundError:
        st.error("❌ 'meal_plan_model.joblib' not found!")
        return None

food_db = load_data()
model = load_model()

if food_db is None or model is None:
    st.error("Please ensure both 'meal_plan_model.joblib' and 'improved_food_database.csv' exist!")
    st.stop()


# --- 4. Helper Functions ---
def calculate_bmr(age, weight_kg, height_cm, gender):
    if gender == "Male":
        return 88.362 + (13.397 * weight_kg) + (4.799 * height_cm) - (5.677 * age)
    else:
        return 447.593 + (9.247 * weight_kg) + (3.098 * height_cm) - (4.330 * age)

def calculate_tdee(bmr, activity_level):
    activity_multipliers = {
        "Light Training (1–3 days/week)": 1.375,
        "Moderate Training (3–5 days/week)": 1.55,
        "High Training (6–7 days/week)": 1.725
    }
    return bmr * activity_multipliers.get(activity_level, 1.55)

# ✅ FIXED GOAL → MODEL MAPPING
def map_goal_to_model_format(goal):
    mapping = {
        "Build Muscle": "High Protein High Carb",
        "Endurance": "High Carb",
        "HIIT": "High Protein Low Carb",
        "Weight Loss": "High Protein Low Carb",
        "General": "Balanced"
    }
    return mapping.get(goal, "Balanced")


def filter_by_meal_plan_rules(food_db, plan):
    """Fallback food filter using nutrition logic (if clusters missing)."""
    if plan == "High Carb":
        return food_db[(food_db['Carbs'] > 40) & (food_db['Proteins'] < 15)]
    elif plan == "High Protein High Carb":
        return food_db[(food_db['Proteins'] > 15) & (food_db['Carbs'] > 30)]
    elif plan == "High Protein Low Carb":
        return food_db[(food_db['Proteins'] > 18) & (food_db['Carbs'] < 25)]
    elif plan == "Low Calorie":
        return food_db[food_db['Calories'] < 200]
    elif plan == "Balanced":
        return food_db[
            (food_db['Proteins'].between(10, 18)) &
            (food_db['Carbs'].between(25, 45))
        ]
    else:
        return food_db


def get_recommendations_by_cluster(food_db, predicted_plan):
    """
    Selects 3 meals that match BMR requirements and nutritional goals.
    Distributes calories as: Breakfast 30%, Lunch 40%, Dinner 30% of BMR.
    """
    # 🧩 Ensure data integrity
    if food_db is None or food_db.empty:
        st.error("❌ Food database is empty or missing.")
        return []

    if 'Meal_Plan' not in food_db.columns:
        st.error("⚠️ 'Meal_Plan' column missing — cannot match clusters.")
        return food_db.sample(min(3, len(food_db))).assign(Meal=["Breakfast", "Lunch", "Dinner"][:len(food_db)])

    # Get BMR from session state
    bmr = st.session_state.get('bmr', 2000)  # Default to 2000 if not found
    
    # Calculate target calories for each meal
    meal_calories = {
        "Breakfast": bmr * 0.30,  # 30% of daily calories
        "Lunch": bmr * 0.40,      # 40% of daily calories
        "Dinner": bmr * 0.30      # 30% of daily calories
    }

    # 1️⃣ Handle Endurance goal or mixed plans dynamically
    user_goal = st.session_state.get("user_data", {}).get("Goals", "").lower()
    if "endurance" in user_goal or "high protein high carb" in predicted_plan.lower():
        filtered = food_db[
            food_db['Meal_Plan'].str.contains("High Protein", case=False, na=False) |
            food_db['Meal_Plan'].str.contains("High Carb", case=False, na=False)
        ]
    else:
        filtered = food_db[food_db['Meal_Plan'].str.contains(predicted_plan, case=False, na=False)]

    # 2️⃣ Fallback — no exact match, find nutritionally similar cluster
    if filtered.empty:
        st.warning(f"⚠️ No foods found for '{predicted_plan}'. Finding closest cluster nutritionally...")
        macro_means = (
            food_db.groupby('Meal_Plan')[['Proteins', 'Carbs', 'Fats']].mean().fillna(0)
        )
        from sklearn.metrics.pairwise import cosine_similarity
        if predicted_plan in macro_means.index:
            target_vec = macro_means.loc[[predicted_plan]].values
        else:
            target_vec = macro_means.mean().values.reshape(1, -1)
        similarities = cosine_similarity(target_vec, macro_means.values)[0]
        closest_cluster = macro_means.index[np.argmax(similarities)]
        filtered = food_db[food_db['Meal_Plan'] == closest_cluster]

    # 3️⃣ If still empty, use balanced foods
    if filtered.empty:
        filtered = food_db

    # 4️⃣ Select meals based on goal-specific nutritional requirements
    meals = []
    meal_types = ["Breakfast", "Lunch", "Dinner"]

    # Define nutritional requirements based on predicted plan
    nutrition_requirements = {
        "High Protein High Carb": {
            'Proteins': {'min': 20, 'target': 25},  # For muscle building
            'Carbs': {'min': 40, 'target': 50},     # High energy needs
            'Fats': {'min': 10, 'target': 15}       # Moderate fats
        },
        "High Protein Low Carb": {
            'Proteins': {'min': 25, 'target': 30},  # For HIIT/Weight Loss
            'Carbs': {'min': 10, 'target': 20},     # Lower carbs
            'Fats': {'min': 15, 'target': 20}       # Higher fats
        },
        "High Carb": {
            'Proteins': {'min': 15, 'target': 20},  # Moderate protein
            'Carbs': {'min': 50, 'target': 60},     # For endurance
            'Fats': {'min': 10, 'target': 15}       # Lower fats
        },
        "Balanced": {
            'Proteins': {'min': 15, 'target': 20},  # Balanced macros
            'Carbs': {'min': 30, 'target': 40},
            'Fats': {'min': 15, 'target': 20}
        }
    }

    # Get requirements for current plan (default to Balanced if not found)
    plan_reqs = nutrition_requirements.get(predicted_plan, nutrition_requirements["Balanced"])
    
    for meal_type in meal_types:
        target_calories = meal_calories[meal_type]
        
        # Filter foods based on plan's nutritional requirements
        suitable_foods = filtered[
            (filtered['Proteins'] >= plan_reqs['Proteins']['min']) &
            (filtered['Carbs'] >= plan_reqs['Carbs']['min']) &
            (filtered['Fats'] >= plan_reqs['Fats']['min'])
        ]
        
        if suitable_foods.empty:
            suitable_foods = filtered  # Fallback to all foods if no matches
        
        # Apply calorie target
        calorie_margin = 0.20
        calorie_filtered = suitable_foods[
            (suitable_foods['Calories'] >= target_calories * (1 - calorie_margin)) &
            (suitable_foods['Calories'] <= target_calories * (1 + calorie_margin))
        ]
        
        if calorie_filtered.empty:
            # If no foods in calorie range, take closest matches
            calorie_filtered = suitable_foods.iloc[
                (suitable_foods['Calories'] - target_calories).abs().argsort()[:5]
            ]
        
        # Select best matching food based on target macros
        selected_food = calorie_filtered.sample(1).iloc[0]
        
        # Calculate how well the food meets macro targets
        macro_scores = {
            'Proteins': min(selected_food['Proteins'] / plan_reqs['Proteins']['target'], 1.0),
            'Carbs': min(selected_food['Carbs'] / plan_reqs['Carbs']['target'], 1.0),
            'Fats': min(selected_food['Fats'] / plan_reqs['Fats']['target'], 1.0)
        }
        
        meals.append({
            "Meal": meal_type,
            "Food": selected_food.get('meal_name', 'Unknown'),
            "Target Calories": f"{target_calories:.0f}",
            "Actual Calories": f"{selected_food.get('Calories', 0):.0f}",
            "Proteins": f"{selected_food.get('Proteins', 0):.1f}g",
            "Carbs": f"{selected_food.get('Carbs', 0):.1f}g",
            "Fats": f"{selected_food.get('Fats', 0):.1f}g",
            "Calories": f"{selected_food.get('Calories', 0):.0f} kcal",
            "Macro Score": f"{sum(macro_scores.values())/3:.0%}"
        })

    return meals




# --- 5. Sidebar ---
with st.sidebar:
    st.title("💪 POWER")
    
    st.markdown("""
    <div style='margin-bottom: 2rem;'>
        <h4 style='color: #60A5FA; margin-bottom: 0.5rem;'>AI-Powered Nutrition</h4>
        <p style='color: #94A3B8; font-size: 0.9rem; line-height: 1.5;'>
            Advanced machine learning algorithms analyze your profile to create personalized meal plans.
        </p>
    </div>
    """, unsafe_allow_html=True)
    
    with st.expander("🎯 System Features"):
        st.markdown("""
        - **Smart Analysis**: K-Means clustering for food grouping
        - **AI Prediction**: Random Forest for meal planning
        - **Dynamic**: Adapts to your goals and needs
        """)
    
    with st.expander("📊 Database Stats"):
        st.metric("Total Foods", f"{len(food_db):,}")
        if 'Meal_Plan' in food_db.columns:
            st.write("#### Plan Distribution")
            st.write(food_db['Meal_Plan'].value_counts())
    st.markdown("---")

# --- 6. Main Page ---
st.title("Athletic Diet AI")
st.markdown("""
<div style='text-align: center; margin-bottom: 2rem;'>
    <p style='color: #94A3B8; font-size: 1.1rem; font-weight: 500;'>
        Precision Nutrition for Peak Performance
    </p>
</div>
""", unsafe_allow_html=True)

# Profile Form Card
st.markdown('<div class="main-card">', unsafe_allow_html=True)
st.markdown("""
<div style='display: flex; align-items: center; margin-bottom: 1.5rem;'>
    <div style='background: linear-gradient(90deg, #1a73e8, #91a7ff); width: 4px; height: 24px; margin-right: 1rem;'></div>
    <h3 style='margin: 0; color: #202124; font-weight:700;'>Athlete Profile</h3>
</div>
""", unsafe_allow_html=True)

col1, col2 = st.columns(2)
with col1:
    age = st.number_input("Age", 15, 80, 25, help="Your current age")
    gender = st.selectbox("Gender", ("Male", "Female"), help="Select your biological gender")
    height_cm = st.number_input("Height (cm)", 140, 220, 170, help="Your height in centimeters")
    weight_kg = st.number_input("Weight (kg)", 40, 150, 70, help="Your current weight in kilograms")
with col2:
    goals = ["Build Muscle", "Endurance", "HIIT", "Weight Loss", "General"]
    goal = st.selectbox("Performance Goal", goals, help="Select your primary fitness goal")
    activity = st.selectbox("Training Frequency", (
        "Light Training (1–3 days/week)",
        "Moderate Training (3–5 days/week)",
        "High Training (6–7 days/week)"
    ), index=1, help="How often do you train per week?")

    st.markdown("<br>", unsafe_allow_html=True)  # Add spacing
    btn = st.button("GENERATE PLAN", use_container_width=True)

st.markdown('</div>', unsafe_allow_html=True)


# --- 7. Backend Logic ---
if btn:
    with st.spinner("Analyzing your profile..."):
        height_m = height_cm / 100
        bmi = weight_kg / (height_m ** 2)
        bmr = calculate_bmr(age, weight_kg, height_cm, gender)
        tdee = calculate_tdee(bmr, activity)

        exp_level = {"Light Training (1–3 days/week)": 2,
                     "Moderate Training (3–5 days/week)": 4,
                     "High Training (6–7 days/week)": 6}[activity]

        user_data = {
            'Age': age, 'Weight (kg)': weight_kg, 'Height (m)': height_m, 'BMI': bmi,
            'Fat_Percentage': 18.0, 'Avg_BPM': 130, 'Resting_BPM': 65,
            'Experience_Level': exp_level, 'Gender': gender,
            'Goals': map_goal_to_model_format(goal).strip().title()

        }

        user_df = pd.DataFrame([user_data])

        # --- Predict using Random Forest ---
        proba = model.predict_proba(user_df)[0]
        classes = model.classes_

        # Boost probability dynamically based on goal
        goal_influence = {
    "Endurance": ["High Protein High Carb", "High Carb"],  # ✅ Now includes both
    "Build Muscle": ["High Protein High Carb"],
    "HIIT": ["High Protein Low Carb"],
    "Weight Loss": ["High Protein Low Carb", "Low Calorie"],
    "General": ["Balanced"]
}


        adjusted_proba = proba.copy()
        if goal in goal_influence:
            for i, c in enumerate(classes):
                if c in goal_influence[goal]:
                    adjusted_proba[i] *= 1.25  # stronger bias (25%)
        adjusted_proba /= np.sum(adjusted_proba)

        predicted_plan = classes[np.argmax(adjusted_proba)]

        st.session_state.update({
            'bmr': bmr,
            'tdee': tdee,
            'bmi': bmi,
            'predicted_plan': predicted_plan,
            'user_data': user_data,
            'meal_plan': pd.DataFrame(get_recommendations_by_cluster(food_db, predicted_plan))
        })


# --- 8. Display Results ---
if st.session_state.get('predicted_plan'):
    st.markdown("<div class='main-card'>", unsafe_allow_html=True)
    
    # Header with gradient line
    st.markdown(f"""
    <div style='display: flex; align-items: center; margin-bottom: 1.5rem;'>
        <div style='background: linear-gradient(90deg, #3B82F6, #10B981); width: 4px; height: 24px; margin-right: 1rem;'></div>
        <h3 style='margin: 0; color: #202124;'>Analysis Results</h3>
    </div>
    """, unsafe_allow_html=True)
    
    # Metrics in a modern grid
    ud = st.session_state['user_data']
    col1, col2, col3 = st.columns(3)
    with col1:
        st.markdown("""
        <div style='background: rgba(59, 130, 246, 0.1); padding: 1rem; border-radius: 12px; text-align: center;'>
            <p style='color: #202124; margin: 0; font-size: 0.9rem;'>BMI</p>
            <h2 style='color: #202124; margin: 0.5rem 0;'>{:.1f}</h2>
        </div>
        """.format(ud['BMI']), unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
        <div style='background: rgba(59, 130, 246, 0.1); padding: 1rem; border-radius: 12px; text-align: center;'>
            <p style='color: #202124; margin: 0; font-size: 0.9rem;'>BMR</p>
            <h2 style='color: #202124; margin: 0.5rem 0;'>{:.0f}</h2>
            <p style='color: #202124; margin: 0; font-size: 0.8rem;'>kcal/day</p>
        </div>
        """.format(st.session_state['bmr']), unsafe_allow_html=True)
    
    with col3:
        st.markdown("""
        <div style='background: rgba(59, 130, 246, 0.1); padding: 1rem; border-radius: 12px; text-align: center;'>
            <p style='color: #202124; margin: 0; font-size: 0.9rem;'>TDEE</p>
            <h2 style='color: #202124; margin: 0.5rem 0;'>{:.0f}</h2>
            <p style='color: #202124; margin: 0; font-size: 0.8rem;'>kcal/day</p>
        </div>
        """.format(st.session_state['tdee']), unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)
    
    # Recommendation card
    st.markdown(f"""
    <div style='background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.2); 
         border-radius: 12px; padding: 1.5rem; margin: 1rem 0;'>
        <p style='color: #202124; margin: 0; font-size: 0.9rem;'>RECOMMENDED PLAN</p>
        <h3 style='color: #202124; margin: 0.5rem 0;'>{st.session_state['predicted_plan']}</h3>
    </div>
    """, unsafe_allow_html=True)

    # Meal Plan Section
    st.markdown("""
    <div style='display: flex; align-items: center; margin: 2rem 0 1rem 0;'>
        <div style='background: linear-gradient(90deg, #3B82F6, #10B981); width: 4px; height: 24px; margin-right: 1rem;'></div>
        <h3 style='margin: 0; color: #202124;'>Your Personalized Meal Plan</h3>
    </div>
    """, unsafe_allow_html=True)
    
    meal_df = st.session_state['meal_plan']
    
    # Calculate totals
    total_calories = sum(float(cal.replace(' kcal', '')) for cal in meal_df['Calories'])
    total_proteins = sum(float(p.replace('g', '')) for p in meal_df['Proteins'])
    total_carbs = sum(float(c.replace('g', '')) for c in meal_df['Carbs'])
    total_fats = sum(float(f.replace('g', '')) for f in meal_df['Fats'])
    
    # Show nutritional context based on predicted plan (robust matching)
    predicted_plan = st.session_state['predicted_plan']
    st.markdown(f"### Nutritional Focus for {predicted_plan}:")
    plan_lower = predicted_plan.lower() if isinstance(predicted_plan, str) else ""

    # Prioritise more specific matches first
    if "high protein" in plan_lower and "high carb" in plan_lower:
        st.info("🎯 Focus: High protein (25g+) and high carbs (50g+) per meal for muscle building and energy")
    elif "high protein" in plan_lower and ("low carb" in plan_lower or "lowcarb" in plan_lower):
        st.info("🎯 Focus: High protein (30g+) and lower carbs (20g) per meal for HIIT/fat loss")
    elif "high protein" in plan_lower:
        # Generic high-protein plan (fallback)
        st.info("🎯 Focus: High protein (25–30g+) per meal to support recovery and muscle maintenance")
    elif "high carb" in plan_lower:
        st.info("🎯 Focus: High carbs (50–60g+) and moderate protein (20g) per meal for endurance")
    elif "low calorie" in plan_lower or "low calorie" in predicted_plan.lower():
        st.info("🎯 Focus: Lower calories per meal to support weight loss while maintaining protein intake")
    else:
        st.info("🎯 Focus: Balanced macronutrients for general fitness")
    
    # Create metrics in columns
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Daily Calorie Target", f"{st.session_state['bmr']:.0f} kcal")
        st.metric("Total Plan Calories", f"{total_calories:.0f} kcal")
    with col2:
        st.metric("Total Protein", f"{total_proteins:.1f}g")
        st.metric("Total Carbs", f"{total_carbs:.1f}g")
    with col3:
        st.metric("Total Fats", f"{total_fats:.1f}g")
        st.metric("Average Macro Score", f"{meal_df['Macro Score'].str.rstrip('%').astype(float).mean():.0f}%")
    
    # Display the meal plan
    st.markdown("### Detailed Meal Plan")
    display_df = meal_df.copy()
    display_columns = ['Food', 'Proteins', 'Carbs', 'Fats', 'Calories', 'Macro Score']
    st.dataframe(display_df.set_index('Meal')[display_columns], use_container_width=True)
    
    # Add nutrition tips
    with st.expander("📋 Nutrition Tips"):
        predicted_plan = st.session_state['predicted_plan']
        st.markdown(f"""
        Based on your {predicted_plan} plan:
        - Protein: {"High priority (25g+ per meal)" if "High Protein" in predicted_plan else "Moderate (15-20g per meal)"}
        - Carbs: {"High priority (50g+ per meal)" if "High Carb" in predicted_plan else "Moderate to low (10-20g per meal)" if "Low Carb" in predicted_plan else "Balanced (30-40g per meal)"}
        - Fats: {"Moderate (15-20g per meal)" if "Low Carb" not in predicted_plan else "Higher (20-25g per meal)"}
        """)

    if st.button("🔄 Regenerate Recommendations", type="secondary", use_container_width=True):
        with st.spinner("Refreshing meals..."):
            new_meals = get_recommendations_by_cluster(food_db, st.session_state['predicted_plan'])
            st.session_state['meal_plan'] = pd.DataFrame(new_meals)
            st.rerun()
